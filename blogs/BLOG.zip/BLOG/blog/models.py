from django.db import models
from django.utils import timezone


class BlogManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(status="published")


class Blog(models.Model):
    OPTIONS = (
        ('draft', "Qoralama"),
        ('published', "Nashir etilgan")
    )
    title = models.CharField(max_length=350, verbose_name="Sarlavha")
    short_content = models.TextField(verbose_name="Qisqa ma`lumot")
    content = models.TextField(verbose_name="Ma`lumot")
    pub_date = models.DateTimeField(default=timezone.now(), verbose_name="Nashir Sanasi")
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=250, choices=OPTIONS, default="draft", verbose_name="Holati")

    objects = models.Manager()
    manager = BlogManager()

    def __str__(self):
        return self.title

    class Meta:
        ordering = ["-pub_date"]

